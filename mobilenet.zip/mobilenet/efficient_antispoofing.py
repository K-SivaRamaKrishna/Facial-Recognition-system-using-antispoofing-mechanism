# ==========================================================
# FACE ANTI-SPOOFING SYSTEM (CASIA DATASET) - FINAL STABLE
# Author: K Siva Rama Krishna
# ==========================================================

import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from sklearn.model_selection import train_test_split
import cv2
import matplotlib.pyplot as plt
import albumentations as A
from tqdm import tqdm
import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
import seaborn as sns
import time
import pickle
import json
from pathlib import Path
import gc

# ==========================================================
# 1️⃣ DATA PREPROCESSOR
# ==========================================================
class RobustCASIAPreprocessor:
    def __init__(self, base_path, output_path="./preprocessed_casia", img_size=(224, 224)):
        self.base_path = base_path
        self.output_path = Path(output_path)
        self.img_size = img_size
        self.preprocessed_path = self.output_path / "images"
        self.metadata_path = self.output_path / "metadata"
        self.preprocessed_path.mkdir(parents=True, exist_ok=True)
        self.metadata_path.mkdir(parents=True, exist_ok=True)
        
        self.train_live_path = Path(base_path) / "train" / "live"
        self.train_spoof_path = Path(base_path) / "train" / "spoof"
        self.test_live_path = Path(base_path) / "test" / "live"
        self.test_spoof_path = Path(base_path) / "test" / "spoof"

    def analyze_dataset(self):
        print("📊 Analyzing dataset...")
        stats = {
            'train_live': len(list(self.train_live_path.glob("*.*"))),
            'train_spoof': len(list(self.train_spoof_path.glob("*.*"))),
            'test_live': len(list(self.test_live_path.glob("*.*"))),
            'test_spoof': len(list(self.test_spoof_path.glob("*.*")))
        }
        print(f"Train Live: {stats['train_live']:,} → load 8K")
        print(f"Train Spoof: {stats['train_spoof']:,} → load 8K")
        print(f"Test Live: {stats['test_live']:,} → load 8K")
        print(f"Test Spoof: {stats['test_spoof']:,} → load 8K")
        print(f"Total: {sum(stats.values()):,} images")

        with open(self.metadata_path / "dataset_stats.json", "w") as f:
            json.dump(stats, f, indent=2)
        return stats

    def ensure_rgb_image(self, img):
        if len(img.shape) == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        elif img.shape[2] == 4:
            img = cv2.cvtColor(img, cv2.COLOR_RGBA2RGB)
        return img

    def preprocess_and_save_images(self, input_path, output_subdir, label, max_images=None):
        output_dir = self.preprocessed_path / output_subdir
        output_dir.mkdir(parents=True, exist_ok=True)
        image_files = list(Path(input_path).glob("*.*"))
        image_files = [f for f in image_files if f.suffix.lower() in ['.jpg', '.png', '.jpeg']]
        if max_images:
            image_files = image_files[:max_images]
        processed_info = []
        print(f"🔄 Preprocessing {len(image_files)} images from {input_path}...")

        for img_path in tqdm(image_files):
            try:
                img = cv2.imread(str(img_path))
                if img is None:
                    continue
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                img = self.ensure_rgb_image(img)
                img = cv2.resize(img, self.img_size)
                output_filename = f"{label}_{img_path.stem}.jpg"
                output_filepath = output_dir / output_filename
                cv2.imwrite(str(output_filepath), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
                processed_info.append({
                    'original_path': str(img_path),
                    'preprocessed_path': str(output_filepath),
                    'label': 0 if label == "live" else 1
                })
            except Exception as e:
                print(f"❌ Error: {e}")
                continue
        return processed_info

    def preprocess_complete_dataset(self, max_images_per_class=8000):
        print("🚀 Starting dataset preprocessing...")
        stats = self.analyze_dataset()
        train_live_info = self.preprocess_and_save_images(self.train_live_path, "train/live", "live", max_images_per_class)
        train_spoof_info = self.preprocess_and_save_images(self.train_spoof_path, "train/spoof", "spoof", max_images_per_class)
        test_live_info = self.preprocess_and_save_images(self.test_live_path, "test/live", "live", max_images_per_class)
        test_spoof_info = self.preprocess_and_save_images(self.test_spoof_path, "test/spoof", "spoof", max_images_per_class)

        with open(self.metadata_path / "train_metadata.pkl", "wb") as f:
            pickle.dump(train_live_info + train_spoof_info, f)
        with open(self.metadata_path / "test_metadata.pkl", "wb") as f:
            pickle.dump(test_live_info + test_spoof_info, f)
        print("✅ Preprocessing complete.")
        return train_live_info + train_spoof_info, test_live_info + test_spoof_info


# ==========================================================
# 2️⃣ UPDATED: MEMORY-SAFE DATA LOADER
# ==========================================================
class SimpleDataLoader:
    def __init__(self, metadata_path, batch_size=32, img_size=(224, 224)):
        self.metadata_path = Path(metadata_path)
        self.batch_size = batch_size
        self.img_size = img_size

    def _load_metadata(self):
        with open(self.metadata_path / "train_metadata.pkl", "rb") as f:
            train_meta = pickle.load(f)
        with open(self.metadata_path / "test_metadata.pkl", "rb") as f:
            test_meta = pickle.load(f)
        return train_meta, test_meta

    def _generator(self, metadata_list):
        for info in metadata_list:
            img = cv2.imread(info['preprocessed_path'])
            if img is None:
                continue
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = cv2.resize(img, self.img_size)
            img = img.astype("float32") / 255.0
            label = np.int32(info['label'])
            yield img, label

    def load_dataset(self, validation_split=0.2):
        print("📂 Building tf.data pipeline...")
        train_meta, test_meta = self._load_metadata()

        # Convert list to tf.data.Dataset generator
        train_ds = tf.data.Dataset.from_generator(
            lambda: self._generator(train_meta),
            output_signature=(
                tf.TensorSpec(shape=(224, 224, 3), dtype=tf.float32),
                tf.TensorSpec(shape=(), dtype=tf.int32)
            )
        )

        test_ds = tf.data.Dataset.from_generator(
            lambda: self._generator(test_meta),
            output_signature=(
                tf.TensorSpec(shape=(224, 224, 3), dtype=tf.float32),
                tf.TensorSpec(shape=(), dtype=tf.int32)
            )
        )

        # Shuffle + batch + prefetch
        train_ds = train_ds.shuffle(8000).batch(self.batch_size).prefetch(tf.data.AUTOTUNE)
        test_ds = test_ds.batch(self.batch_size).prefetch(tf.data.AUTOTUNE)

        print("✅ Dataset pipelines ready (no full RAM loading).")
        return train_ds, test_ds

# ==========================================================
# 3️⃣ MODEL DEFINITION
# ==========================================================
class MobileNetV3AntiSpoofModel:
    def __init__(self, img_size=(224, 224), num_classes=2):
        self.img_size = img_size
        self.num_classes = num_classes
        self.model = None

    def build_model(self):
        try:
            base = keras.applications.MobileNetV3Large(
                input_shape=(*self.img_size, 3), include_top=False, pooling="avg", weights="imagenet"
            )
        except Exception:
            base = keras.applications.MobileNetV2(
                input_shape=(*self.img_size, 3), include_top=False, pooling="avg", weights="imagenet"
            )

        base.trainable = False
        inputs = keras.Input(shape=(*self.img_size, 3))
        x = base(inputs, training=False)
        x = keras.layers.Dropout(0.4)(x)
        x = keras.layers.Dense(256, activation="relu")(x)
        x = keras.layers.BatchNormalization()(x)
        x = keras.layers.Dropout(0.5)(x)
        outputs = keras.layers.Dense(self.num_classes, activation="softmax")(x)
        self.model = keras.Model(inputs, outputs)
        return self.model

    def compile_model(self):
        self.model.compile(
            optimizer=keras.optimizers.Adam(1e-3),
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"]
        )
        print("✅ Model compiled successfully.")

    def train(self, train_ds, val_ds, epochs=10):
        history = self.model.fit(
            train_ds,
            validation_data=val_ds,
            epochs=epochs,
            verbose=1,
            callbacks=[
                keras.callbacks.ReduceLROnPlateau(patience=5),
                keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True)
            ]
        )
        return history


# ==========================================================
# 4️⃣ EVALUATOR
# ==========================================================
class ModelEvaluator:
    def __init__(self, model):
        self.model = model

    def evaluate(self, X_test, y_test):
        y_pred = np.argmax(self.model.predict(X_test), axis=1)
        print("\n📊 Classification Report:")
        print(classification_report(y_test, y_pred, target_names=["Live", "Spoof"]))
        
        # Confusion Matrix
        cm = confusion_matrix(y_test, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["Live", "Spoof"], yticklabels=["Live", "Spoof"])
        plt.title("Confusion Matrix")
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.show()
        
        # ROC AUC Score
        y_pred_proba = self.model.predict(X_test)[:, 1]
        auc_score = roc_auc_score(y_test, y_pred_proba)
        print(f"📈 ROC AUC Score: {auc_score:.4f}")
        
        return y_pred, auc_score


# ==========================================================
# 5️⃣ ADVANCED DATA AUGMENTATION
# ==========================================================
class DataAugmentor:
    def __init__(self, img_size=(224, 224)):
        self.img_size = img_size
        self.augmentation = A.Compose([
            A.HorizontalFlip(p=0.5),
            A.RandomBrightnessContrast(p=0.3),
            A.RandomGamma(p=0.2),
            A.GaussNoise(p=0.2),
            A.MotionBlur(blur_limit=3, p=0.2),
            A.RandomRotate90(p=0.2),
            A.HueSaturationValue(p=0.3),
        ])
    
    def augment_image(self, image):
        augmented = self.augmentation(image=image)
        return augmented['image']


# ==========================================================
# 6️⃣ MODEL TRAINER
# ==========================================================
class ModelTrainer:
    def __init__(self, model, train_ds, val_ds):
        self.model = model
        self.train_ds = train_ds
        self.val_ds = val_ds
        self.history = None
    
    def train(self, epochs=15):
        print("🚀 Starting model training...")
        
        callbacks = [
            keras.callbacks.ReduceLROnPlateau(
                monitor='val_loss',
                factor=0.5,
                patience=5,
                min_lr=1e-7,
                verbose=1
            ),
            keras.callbacks.EarlyStopping(
                monitor='val_loss',
                patience=10,
                restore_best_weights=True,
                verbose=1
            ),
            keras.callbacks.ModelCheckpoint(
                'best_model.h5',
                monitor='val_accuracy',
                save_best_only=True,
                verbose=1
            )
        ]
        
        self.history = self.model.fit(
            self.train_ds,
            epochs=epochs,
            validation_data=self.val_ds,
            callbacks=callbacks,
            verbose=1
        )
        return self.history
    
    def plot_training_history(self):
        if self.history is None:
            print("No training history available.")
            return
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
        
        # Plot accuracy
        ax1.plot(self.history.history['accuracy'], label='Training Accuracy')
        ax1.plot(self.history.history['val_accuracy'], label='Validation Accuracy')
        ax1.set_title('Model Accuracy')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Accuracy')
        ax1.legend()
        ax1.grid(True)
        
        # Plot loss
        ax2.plot(self.history.history['loss'], label='Training Loss')
        ax2.plot(self.history.history['val_loss'], label='Validation Loss')
        ax2.set_title('Model Loss')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Loss')
        ax2.legend()
        ax2.grid(True)
        
        plt.tight_layout()
        plt.show()


# ==========================================================
# 7️⃣ MAIN EXECUTION (FIXED)
# ==========================================================
def main():
    BASE_PATH = r"C:\Users\DELL\Downloads\archive (1)\casia-fasd"
    OUTPUT_PATH = "./preprocessed_casia_final"
    BATCH_SIZE = 32
    IMG_SIZE = (224, 224)
    EPOCHS = 15

    print("🚀 Starting Face Anti-Spoofing System...")
    print("=" * 50)

    # Step 1: Preprocess dataset
    print("📁 Step 1: Data Preprocessing")
    preprocessor = RobustCASIAPreprocessor(BASE_PATH, OUTPUT_PATH)
    
    # Check if preprocessing is already done
    metadata_files_exist = (preprocessor.metadata_path / "train_metadata.pkl").exists() and \
                          (preprocessor.metadata_path / "test_metadata.pkl").exists()
    
    if not metadata_files_exist or not list(preprocessor.preprocessed_path.glob("**/*.jpg")):
        print("🔄 Preprocessing dataset...")
        train_meta, test_meta = preprocessor.preprocess_complete_dataset(8000)
    else:
        print("✅ Using already preprocessed dataset.")

    # Step 2: Create data loaders
    print("\n📁 Step 2: Creating Data Loaders")
    data_loader = SimpleDataLoader(preprocessor.metadata_path, batch_size=BATCH_SIZE)
    train_ds, test_ds = data_loader.load_dataset()

    # Step 3: Build and compile model
    print("\n🔄 Step 3: Building Model")
    model_wrapper = MobileNetV3AntiSpoofModel(img_size=IMG_SIZE)
    model_wrapper.build_model()
    model_wrapper.compile_model()
    
    # Print model summary
    print("\n📋 Model Architecture:")
    model_wrapper.model.summary()

    # Step 4: Train model
    print("\n🚀 Step 4: Training Model")
    trainer = ModelTrainer(model_wrapper.model, train_ds, test_ds)
    history = trainer.train(epochs=EPOCHS)
    
    # Plot training history
    trainer.plot_training_history()

    # Step 5: Evaluate model
    print("\n📊 Step 5: Evaluating Model")
    evaluator = ModelEvaluator(model_wrapper.model)
    
    # Convert test dataset to numpy arrays for evaluation
    print("🔄 Preparing test data for evaluation...")
    X_test, y_test = [], []
    for imgs, labels in test_ds:
        X_test.append(imgs.numpy())
        y_test.append(labels.numpy())
    
    X_test = np.concatenate(X_test, axis=0)
    y_test = np.concatenate(y_test, axis=0)
    
    print(f"Test set size: {len(X_test)} samples")
    evaluator.evaluate(X_test, y_test)

    # Step 6: Save model
    print("\n💾 Step 6: Saving Model")
    model_wrapper.model.save("final_mobilenetv3_antispoof.h5")
    print("✅ Model saved successfully as 'final_mobilenetv3_antispoof.h5'")

    # Step 7: Additional info
    print("\n📈 Training Completed Successfully!")
    print("=" * 50)
    final_accuracy = history.history['val_accuracy'][-1]
    final_loss = history.history['val_loss'][-1]
    print(f"Final Validation Accuracy: {final_accuracy:.4f}")
    print(f"Final Validation Loss: {final_loss:.4f}")

    # Clean up
    gc.collect()

if __name__ == "__main__":
    main()