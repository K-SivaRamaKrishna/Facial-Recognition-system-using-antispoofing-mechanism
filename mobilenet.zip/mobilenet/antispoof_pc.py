import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from sklearn.model_selection import train_test_split
import cv2
import matplotlib.pyplot as plt
from imgaug import augmenters as iaa
import albumentations as A

class CASIADataPreprocessor:
    def __init__(self, base_path, img_size=(224, 224)):
        self.base_path = base_path
        self.img_size = img_size
        self.train_live_path = os.path.join(base_path, "train", "live")
        self.train_spoof_path = os.path.join(base_path, "train", "spoof") 
        self.test_live_path = os.path.join(base_path, "test", "live")
        self.test_spoof_path = os.path.join(base_path, "test", "spoof")
        
    def check_dataset_structure(self):
        """Verify dataset structure"""
        paths = [
            self.train_live_path,
            self.train_spoof_path, 
            self.test_live_path,
            self.test_spoof_path
        ]
        
        for path in paths:
            if not os.path.exists(path):
                print(f"Warning: {path} does not exist")
            else:
                num_files = len([f for f in os.listdir(path) if f.endswith(('.jpg', '.png', '.jpeg'))])
                print(f"{path}: {num_files} images")
                
    def balance_and_augment(self, images, labels, target_count=None):
        """Balance classes through augmentation"""
        live_count = np.sum(labels == 0)
        spoof_count = np.sum(labels == 1)
        
        print(f"Before balancing - Live: {live_count}, Spoof: {spoof_count}")
        
        if target_count is None:
            target_count = max(live_count, spoof_count)
            
        # Augmentation pipeline
        augmenter = A.Compose([
            A.HorizontalFlip(p=0.5),
            A.RandomBrightnessContrast(p=0.2),
            A.RandomGamma(p=0.2),
            A.GaussNoise(p=0.3),
            A.MotionBlur(p=0.2),
            A.RandomRotate90(p=0.3),
        ])
        
        balanced_images = []
        balanced_labels = []
        
        for class_idx in [0, 1]:
            class_images = images[labels == class_idx]
            class_count = len(class_images)
            
            if class_count < target_count:
                # Augment to reach target count
                num_to_generate = target_count - class_count
                augmented = []
                
                for i in range(num_to_generate):
                    img = class_images[i % class_count]
                    augmented_img = augmenter(image=img)['image']
                    augmented.append(augmented_img)
                
                balanced_images.extend(class_images)
                balanced_images.extend(augmented)
                balanced_labels.extend([class_idx] * (class_count + num_to_generate))
            else:
                balanced_images.extend(class_images[:target_count])
                balanced_labels.extend([class_idx] * target_count)
                
        return np.array(balanced_images), np.array(balanced_labels)
    
    def load_and_preprocess_images(self):
        """Load all images and preprocess"""
        all_images = []
        all_labels = []
        
        # Load training data
        for label, (path, class_idx) in enumerate([
            (self.train_live_path, 0),  # live = 0
            (self.train_spoof_path, 1)  # spoof = 1
        ]):
            if os.path.exists(path):
                for img_file in os.listdir(path):
                    if img_file.lower().endswith(('.png', '.jpg', '.jpeg')):
                        img_path = os.path.join(path, img_file)
                        img = cv2.imread(img_path)
                        if img is not None:
                            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                            img = cv2.resize(img, self.img_size)
                            img = img.astype(np.float32) / 255.0
                            all_images.append(img)
                            all_labels.append(class_idx)
        
        all_images = np.array(all_images)
        all_labels = np.array(all_labels)
        
        # Balance dataset
        balanced_images, balanced_labels = self.balance_and_augment(all_images, all_labels)
        
        return balanced_images, balanced_labels
    
    def create_data_generator(self, validation_split=0.2):
        """Create data generators with augmentation"""
        images, labels = self.load_and_preprocess_images()
        
        # Split data
        X_train, X_val, y_train, y_val = train_test_split(
            images, labels, test_size=validation_split, 
            stratify=labels, random_state=42
        )
        
        # Data augmentation for training
        train_datagen = keras.preprocessing.image.ImageDataGenerator(
            rotation_range=20,
            width_shift_range=0.2,
            height_shift_range=0.2,
            horizontal_flip=True,
            zoom_range=0.2,
            shear_range=0.1,
            fill_mode='nearest'
        )
        
        # Validation data (no augmentation)
        val_datagen = keras.preprocessing.image.ImageDataGenerator()
        
        return (X_train, y_train), (X_val, y_val), train_datagen, val_datagen
class AntiSpoofModel:
    def __init__(self, img_size=(224, 224), num_classes=2):
        self.img_size = img_size
        self.num_classes = num_classes
        self.model = None
        
    def build_mobilenetv3_model(self):
        """Build MobileNetV3 with custom head"""
        base_model = keras.applications.MobileNetV3Large(
            input_shape=(*self.img_size, 3),
            include_top=False,
            weights='imagenet',
            pooling='avg'
        )
        
        # Freeze base model initially
        base_model.trainable = False
        
        inputs = keras.Input(shape=(*self.img_size, 3))
        x = base_model(inputs, training=False)
        x = keras.layers.Dropout(0.3)(x)
        x = keras.layers.Dense(128, activation='relu')(x)
        x = keras.layers.BatchNormalization()(x)
        x = keras.layers.Dropout(0.5)(x)
        outputs = keras.layers.Dense(self.num_classes, activation='softmax')(x)
        
        self.model = keras.Model(inputs, outputs)
        
        return self.model
    
    def compile_model(self, learning_rate=0.001):
        """Compile the model"""
        self.model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy', 'precision', 'recall']
        )
    
    def train(self, X_train, y_train, X_val, y_val, train_datagen, val_datagen,
              batch_size=32, epochs_head=10, epochs_finetune=20):
        """Two-phase training: head training then fine-tuning"""
        
        # Phase 1: Train only the head
        print("Phase 1: Training head...")
        history1 = self.model.fit(
            train_datagen.flow(X_train, y_train, batch_size=batch_size),
            epochs=epochs_head,
            validation_data=val_datagen.flow(X_val, y_val),
            verbose=1
        )
        
        # Phase 2: Fine-tune the base model
        print("Phase 2: Fine-tuning...")
        self.model.trainable = True
        
        # Use lower learning rate for fine-tuning
        self.compile_model(learning_rate=0.0001)
        
        history2 = self.model.fit(
            train_datagen.flow(X_train, y_train, batch_size=batch_size),
            epochs=epochs_finetune,
            validation_data=val_datagen.flow(X_val, y_val),
            verbose=1
        )
        
        # Combine histories
        combined_history = {}
        for key in history1.history.keys():
            combined_history[key] = history1.history[key] + history2.history[key]
            
        return combined_history
    
    def save_model(self, filepath):
        """Save the trained model"""
        self.model.save(filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath):
        """Load a trained model"""
        self.model = keras.models.load_model(filepath)
        print(f"Model loaded from {filepath}")
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
import seaborn as sns

class ModelEvaluator:
    def __init__(self, model):
        self.model = model
        
    def evaluate_model(self, X_test, y_test):
        """Comprehensive model evaluation"""
        # Predictions
        y_pred_proba = self.model.predict(X_test)
        y_pred = np.argmax(y_pred_proba, axis=1)
        
        # Metrics
        accuracy = np.mean(y_pred == y_test)
        precision = tf.keras.metrics.Precision()(y_test, y_pred)
        recall = tf.keras.metrics.Recall()(y_test, y_pred)
        auc = roc_auc_score(y_test, y_pred_proba[:, 1])
        
        print(f"Accuracy: {accuracy:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall: {recall:.4f}")
        print(f"AUC: {auc:.4f}")
        
        # Classification report
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred, target_names=['Live', 'Spoof']))
        
        # Confusion matrix
        self.plot_confusion_matrix(y_test, y_pred)
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'auc': auc,
            'y_pred': y_pred,
            'y_pred_proba': y_pred_proba
        }
    
    def plot_confusion_matrix(self, y_true, y_pred):
        """Plot confusion matrix"""
        cm = confusion_matrix(y_true, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                   xticklabels=['Live', 'Spoof'],
                   yticklabels=['Live', 'Spoof'])
        plt.xlabel('Predicted')
        plt.ylabel('Actual')
        plt.title('Confusion Matrix')
        plt.show()
def main():
    # Initialize preprocessor
    base_path = r"C:\Users\DELL\Downloads\archive (1)\casia-fasd"
    preprocessor = CASIADataPreprocessor(base_path)
    
    # Check dataset structure
    preprocessor.check_dataset_structure()
    
    # Prepare data
    (X_train, y_train), (X_val, y_val), train_datagen, val_datagen = preprocessor.create_data_generator()
    
    print(f"Training set: {X_train.shape[0]} samples")
    print(f"Validation set: {X_val.shape[0]} samples")
    
    # Build and train model
    antispoof_model = AntiSpoofModel()
    model = antispoof_model.build_mobilenetv3_model()
    antispoof_model.compile_model()
    
    # Train model
    history = antispoof_model.train(
        X_train, y_train, X_val, y_val, 
        train_datagen, val_datagen,
        epochs_head=15,
        epochs_finetune=25
    )
    
    # Save model
    antispoof_model.save_model("antispoof_casia.h5")
    
    # Evaluate model
    evaluator = ModelEvaluator(antispoof_model.model)
    results = evaluator.evaluate_model(X_val, y_val)
    
    # Plot training history
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.plot(history['accuracy'], label='Training Accuracy')
    plt.plot(history['val_accuracy'], label='Validation Accuracy')
    plt.title('Model Accuracy')
    plt.legend()
    
    plt.subplot(1, 2, 2)
    plt.plot(history['loss'], label='Training Loss')
    plt.plot(history['val_loss'], label='Validation Loss')
    plt.title('Model Loss')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()
