import cv2
import numpy as np
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
from pathlib import Path

class LiveFaceAntiSpoofing:
    def __init__(self):
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.img_size = (224, 224)
        
    def detect_faces(self, frame):
        """Detect faces in the frame"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)
        return faces
    
    def analyze_face_heuristic(self, face_roi):
        """Analyze face region using heuristics"""
        # Convert to RGB for analysis
        face_rgb = cv2.cvtColor(face_roi, cv2.COLOR_BGR2RGB)
        
        # Convert to different color spaces
        hsv = cv2.cvtColor(face_rgb, cv2.COLOR_RGB2HSV)
        lab = cv2.cvtColor(face_rgb, cv2.COLOR_RGB2LAB)
        
        # Calculate features
        brightness = np.mean(lab[:,:,0]) / 255.0
        color_std = np.std(face_rgb) / 255.0
        edge_density = self.calculate_edge_density(face_rgb)
        texture_score = self.analyze_texture(face_rgb)
        reflection_score = self.analyze_reflections(face_rgb)
        
        # Spoof scoring
        spoof_score = 0
        
        if brightness > 0.8 or brightness < 0.2:
            spoof_score += 1
        if color_std < 0.1:
            spoof_score += 1
        if edge_density < 0.05 or edge_density > 0.8:
            spoof_score += 1
        if texture_score < 0.3:
            spoof_score += 1
        if reflection_score > 0.7:
            spoof_score += 1
        
        # Decision
        if spoof_score >= 3:
            result = "SPOOF"
            confidence = min(0.95, 0.6 + (spoof_score * 0.1))
        else:
            result = "LIVE"
            confidence = min(0.95, 0.7 - (spoof_score * 0.1))
        
        return result, confidence, spoof_score
    
    def calculate_edge_density(self, img):
        """Calculate edge density"""
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        edge_density = np.sum(edges > 0) / (img.shape[0] * img.shape[1])
        return edge_density
    
    def analyze_texture(self, img):
        """Analyze texture complexity"""
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        texture_score = min(1.0, laplacian_var / 1000.0)
        return texture_score
    
    def analyze_reflections(self, img):
        """Analyze potential reflections"""
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        brightness = hsv[:,:,2].astype(float)
        bright_spots = np.sum(brightness > 200) / brightness.size
        return bright_spots
    
    def start_webcam_analysis(self):
        """Start real-time webcam analysis"""
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("❌ Cannot access webcam")
            return
        
        print("🚀 Starting live face anti-spoofing analysis...")
        print("📋 Instructions:")
        print("   - Look directly at the camera")
        print("   - Ensure good lighting")
        print("   - Press 'q' to quit")
        print("   - Press 's' to save current frame")
        
        saved_frames = []
        
        while True:
            ret, frame = cap.read()
            if not ret:
                print("❌ Failed to capture frame")
                break
            
            # Flip frame horizontally for mirror effect
            frame = cv2.flip(frame, 1)
            
            # Detect faces
            faces = self.detect_faces(frame)
            
            # Analyze each face
            for (x, y, w, h) in faces:
                # Extract face ROI
                face_roi = frame[y:y+h, x:x+w]
                
                # Resize for analysis
                face_roi_resized = cv2.resize(face_roi, self.img_size)
                
                # Analyze face
                result, confidence, spoof_score = self.analyze_face_heuristic(face_roi_resized)
                
                # Draw rectangle and results
                color = (0, 255, 0) if result == "LIVE" else (0, 0, 255)  # Green for LIVE, Red for SPOOF
                cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                
                # Display results
                status_text = f"{result} ({confidence:.2f})"
                cv2.putText(frame, status_text, (x, y-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                
                # Display spoof score
                score_text = f"Spoof Score: {spoof_score}/5"
                cv2.putText(frame, score_text, (x, y+h+25), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
                
                # Add analysis details
                details_text = f"Press 's' to save analysis"
                cv2.putText(frame, details_text, (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            
            # Display frame
            cv2.imshow('Live Face Anti-Spoofing', frame)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s') and len(faces) > 0:
                # Save current frame with analysis
                self.save_analysis_frame(frame, faces, saved_frames)
        
        cap.release()
        cv2.destroyAllWindows()
        
        # Show saved frames analysis
        if saved_frames:
            self.show_saved_analysis(saved_frames)
    
    def save_analysis_frame(self, frame, faces, saved_frames):
        """Save frame with analysis for later review"""
        for (x, y, w, h) in faces:
            face_roi = frame[y:y+h, x:x+w]
            face_roi_resized = cv2.resize(face_roi, self.img_size)
            
            # Analyze face
            result, confidence, spoof_score = self.analyze_face_heuristic(face_roi_resized)
            
            saved_frame = {
                'frame': frame.copy(),
                'face_roi': face_roi_resized,
                'result': result,
                'confidence': confidence,
                'spoof_score': spoof_score,
                'timestamp': np.datetime64('now')
            }
            saved_frames.append(saved_frame)
            
            print(f"💾 Saved frame: {result} (Confidence: {confidence:.3f})")
    
    def show_saved_analysis(self, saved_frames):
        """Show detailed analysis of saved frames"""
        print(f"\n📊 Analysis of {len(saved_frames)} saved frames:")
        
        for i, saved in enumerate(saved_frames):
            plt.figure(figsize=(15, 5))
            
            # Original frame with detection
            plt.subplot(1, 3, 1)
            frame_rgb = cv2.cvtColor(saved['frame'], cv2.COLOR_BGR2RGB)
            plt.imshow(frame_rgb)
            plt.title(f"Frame {i+1} - {saved['result']}", fontweight='bold')
            plt.axis('off')
            
            # Face ROI
            plt.subplot(1, 3, 2)
            face_rgb = cv2.cvtColor(saved['face_roi'], cv2.COLOR_BGR2RGB)
            plt.imshow(face_rgb)
            plt.title("Face Region", fontweight='bold')
            plt.axis('off')
            
            # Analysis results
            plt.subplot(1, 3, 3)
            plt.axis('off')
            
            bg_color = 'lightgreen' if saved['result'] == "LIVE" else 'lightcoral'
            text_color = 'darkgreen' if saved['result'] == "LIVE" else 'darkred'
            
            analysis_text = f"DETAILED ANALYSIS\n"
            analysis_text += f"══════════════════\n\n"
            analysis_text += f"Result: {saved['result']}\n\n"
            analysis_text += f"Confidence: {saved['confidence']:.3f}\n\n"
            analysis_text += f"Spoof Score: {saved['spoof_score']}/5\n\n"
            analysis_text += f"Timestamp: {saved['timestamp']}\n\n"
            
            if saved['result'] == "LIVE":
                analysis_text += "✅ Likely genuine face\n"
                analysis_text += "Natural characteristics detected"
            else:
                analysis_text += "🚨 Possible spoof attack\n"
                analysis_text += "Multiple spoof indicators"
            
            plt.text(0.1, 0.9, analysis_text, transform=plt.gca().transAxes, 
                    fontsize=12, verticalalignment='top', color=text_color,
                    bbox=dict(boxstyle='round', facecolor=bg_color, alpha=0.8),
                    fontweight='bold')
            
            plt.tight_layout()
            plt.show()

def quick_test_with_image():
    """Quick test using an image file of a live face"""
    TEST_IMAGE = r"C:\Users\DELL\Downloads\s9v2f6.png"  # Change this to your live face image
    
    if not Path(TEST_IMAGE).exists():
        print(f"❌ Test image not found: {TEST_IMAGE}")
        print("Please update the TEST_IMAGE path to your live face image")
        return
    
    analyzer = LiveFaceAntiSpoofing()
    
    # Load and analyze image
    img = cv2.imread(TEST_IMAGE)
    if img is None:
        print("❌ Could not load image")
        return
    
    # Detect faces
    faces = analyzer.detect_faces(img)
    
    if len(faces) == 0:
        print("❌ No faces detected in the image")
        print("Try a clearer image with a visible face")
        return
    
    print(f"🔍 Found {len(faces)} face(s) in the image")
    
    for i, (x, y, w, h) in enumerate(faces):
        face_roi = img[y:y+h, x:x+w]
        face_roi_resized = cv2.resize(face_roi, analyzer.img_size)
        
        result, confidence, spoof_score = analyzer.analyze_face_heuristic(face_roi_resized)
        
        print(f"\n📊 Face {i+1} Analysis:")
        print(f"   Result: {result}")
        print(f"   Confidence: {confidence:.3f}")
        print(f"   Spoof Score: {spoof_score}/5")
        
        # Display results
        plt.figure(figsize=(12, 4))
        
        plt.subplot(1, 2, 1)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        cv2.rectangle(img_rgb, (x, y), (x+w, y+h), (0, 255, 0), 2)
        plt.imshow(img_rgb)
        plt.title("Detected Face", fontweight='bold')
        plt.axis('off')
        
        plt.subplot(1, 2, 2)
        face_rgb = cv2.cvtColor(face_roi_resized, cv2.COLOR_BGR2RGB)
        plt.imshow(face_rgb)
        plt.title(f"Analysis: {result}\nConfidence: {confidence:.3f}", fontweight='bold')
        plt.axis('off')
        
        plt.tight_layout()
        plt.show()

def main():
    print("🔍 Live Face Anti-Spoofing Test")
    print("=" * 50)
    print("Choose testing method:")
    print("1. Real-time Webcam Analysis")
    print("2. Test with Image File")
    print("3. Both")
    
    choice = input("\nEnter your choice (1/2/3): ").strip()
    
    analyzer = LiveFaceAntiSpoofing()
    
    if choice == "1":
        print("\n🎥 Starting webcam analysis...")
        analyzer.start_webcam_analysis()
    elif choice == "2":
        print("\n🖼️ Testing with image file...")
        quick_test_with_image()
    elif choice == "3":
        print("\n🖼️ First testing with image file...")
        quick_test_with_image()
        print("\n🎥 Now starting webcam analysis...")
        analyzer.start_webcam_analysis()
    else:
        print("❌ Invalid choice. Using webcam analysis...")
        analyzer.start_webcam_analysis()

if __name__ == "__main__":
    main()