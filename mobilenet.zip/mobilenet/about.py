# simple_model_info.py
import h5py
import json
from pathlib import Path

def simple_model_info(model_path):
    """Get basic model information without loading the full model"""
    print("🔍 SIMPLE MODEL INFORMATION")
    print("=" * 50)
    
    model_file = Path(model_path)
    if not model_file.exists():
        print("❌ Model file not found")
        return
    
    print(f"📁 File: {model_file.name}")
    print(f"📦 Size: {model_file.stat().st_size / (1024 * 1024):.2f} MB")
    print()
    
    try:
        with h5py.File(model_path, 'r') as f:
            # Check model configuration
            if 'model_config' in f.attrs:
                config_str = f.attrs['model_config']
                if isinstance(config_str, bytes):
                    config_str = config_str.decode('utf-8')
                config = json.loads(config_str)
                
                model_class = config.get('class_name', 'Unknown')
                print(f"🏷️ Model Type: {model_class}")
                
                # Get layer information from config
                if 'config' in config and 'layers' in config['config']:
                    layers = config['config']['layers']
                    print(f"📈 Total Layers: {len(layers)}")
                    
                    # Count layer types
                    layer_types = {}
                    for layer in layers:
                        ltype = layer.get('class_name', 'Unknown')
                        layer_types[ltype] = layer_types.get(ltype, 0) + 1
                    
                    print("📊 Layer Types:")
                    for ltype, count in layer_types.items():
                        print(f"  • {ltype}: {count}")
            
            # Check for training configuration
            if 'training_config' in f.attrs:
                print("✅ Training configuration found")
            
            # Check model weights
            if 'model_weights' in f:
                print("✅ Model weights found")
                # Count weight arrays
                weight_count = 0
                def count_weights(name, obj):
                    nonlocal weight_count
                    if isinstance(obj, h5py.Dataset):
                        weight_count += 1
                f['model_weights'].visititems(count_weights)
                print(f"⚖️ Weight arrays: {weight_count}")
            
    except Exception as e:
        print(f"❌ Error: {e}")

# Run the simple analysis
MODEL_PATH = r"C:\Users\DELL\Downloads\best_model.h5"
simple_model_info(MODEL_PATH)