# ==========================================================
# FACE ANTI-SPOOFING — PREPROCESS & SAVE RANDOM SAMPLES
# Applies same preprocessing (resize 224x224, rescale 1./255)
# Saves 10 random preprocessed images from each class
# ==========================================================

import os
import random
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.preprocessing.image import load_img, img_to_array, array_to_img

# ---------------------------
# CONFIG
# ---------------------------
DATA_DIR = r"C:\Users\DELL\OneDrive\Pictures\data"
OUTPUT_DIR = os.path.join(DATA_DIR, "preprocessed_samples")
IMG_SIZE = (224, 224)
NUM_SAMPLES = 10
SEED = 42

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

# ---------------------------
# Helper functions
# ---------------------------
def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def preprocess_image(img_path):
    """Load, resize, and rescale image (same as training preprocessing)."""
    img = load_img(img_path, target_size=IMG_SIZE)
    img_array = img_to_array(img)
    img_array = img_array / 255.0  # rescale
    return img_array

def save_preprocessed_image(img_array, save_path):
    """Save preprocessed (0-1) image as PNG."""
    img = array_to_img(img_array)
    img.save(save_path)

def show_images(image_list, title):
    plt.figure(figsize=(12, 5))
    for i, img in enumerate(image_list):
        plt.subplot(2, 5, i + 1)
        plt.imshow(img)
        plt.axis("off")
    plt.suptitle(title, fontsize=14)
    plt.tight_layout()
    plt.show()

# ---------------------------
# Load file paths
# ---------------------------
real_dir = os.path.join(DATA_DIR, "real")
spoof_dir = os.path.join(DATA_DIR, "spoof")

real_images = [os.path.join(real_dir, f) for f in os.listdir(real_dir)
               if f.lower().endswith((".jpg", ".jpeg", ".png"))]
spoof_images = [os.path.join(spoof_dir, f) for f in os.listdir(spoof_dir)
                if f.lower().endswith((".jpg", ".jpeg", ".png"))]

# Random sample
real_samples = random.sample(real_images, min(NUM_SAMPLES, len(real_images)))
spoof_samples = random.sample(spoof_images, min(NUM_SAMPLES, len(spoof_images)))

# ---------------------------
# Preprocess + Save
# ---------------------------
save_real_dir = os.path.join(OUTPUT_DIR, "real")
save_spoof_dir = os.path.join(OUTPUT_DIR, "spoof")
ensure_dir(save_real_dir)
ensure_dir(save_spoof_dir)

real_preprocessed = []
spoof_preprocessed = []

for i, path in enumerate(real_samples):
    img = preprocess_image(path)
    real_preprocessed.append(img)
    save_path = os.path.join(save_real_dir, f"real_{i+1:02d}.png")
    save_preprocessed_image(img, save_path)

for i, path in enumerate(spoof_samples):
    img = preprocess_image(path)
    spoof_preprocessed.append(img)
    save_path = os.path.join(save_spoof_dir, f"spoof_{i+1:02d}.png")
    save_preprocessed_image(img, save_path)

print(f"Saved {len(real_preprocessed)} preprocessed REAL images to: {save_real_dir}")
print(f"Saved {len(spoof_preprocessed)} preprocessed SPOOF images to: {save_spoof_dir}")

# ---------------------------
# Display results
# ---------------------------
show_images(real_preprocessed, "Preprocessed REAL Images")
show_images(spoof_preprocessed, "Preprocessed SPOOF Images")

print("✅ Preprocessing complete. All sample images saved and displayed.")
