# ==========================================================
# FACE ANTI-SPOOFING — SAFE RETRAIN (Vision Transformer)
# ==========================================================
# This script:
# - Loads the existing ViT model safely.
# - Copies it to a new folder (newdatasetmodel/).
# - Retrains on new dataset (real/spoof).
# - Saves everything (history, AUC, confusion matrix, etc.)
#   with prefix "newdatavit" to keep the base model safe.
# ==========================================================

import os
import time
import json
import glob
import math
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import confusion_matrix, classification_report, roc_auc_score, roc_curve
import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model
from sklearn.utils import shuffle, class_weight

# ----------------------------------------------------------
# CONFIG
# ----------------------------------------------------------
BASE_MODEL_PATH = r"results_ViT/ViTmodel.keras"
NEW_DATASET_DIR = r"C:\Users\DELL\OneDrive\Pictures\data"
NEW_RESULTS_DIR = "newdatasetmodel"

IMG_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 25
SEED = 42
os.makedirs(NEW_RESULTS_DIR, exist_ok=True)
CHECKPOINT_DIR = os.path.join(NEW_RESULTS_DIR, "checkpoints_newdatavit")
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# Output file names
BEST_MODEL_KERAS = os.path.join(NEW_RESULTS_DIR, "newdatavit_model.keras")
BEST_MODEL_H5 = os.path.join(NEW_RESULTS_DIR, "newdatavit_model.h5")
HISTORY_CSV = os.path.join(NEW_RESULTS_DIR, "training_history_newdatavit.csv")
RESUME_JSON = os.path.join(NEW_RESULTS_DIR, "resume_info_newdatavit.json")
TFLITE_PATH = os.path.join(NEW_RESULTS_DIR, "newdatavit_model.tflite")

# ----------------------------------------------------------
# Load custom layers (needed for loading ViT)
# ----------------------------------------------------------
class Patches(keras.layers.Layer):
    def __init__(self, patch_size, **kwargs):
        super().__init__(**kwargs)
        self.patch_size = patch_size

    def call(self, images):
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1, 1, 1, 1],
            padding="VALID",
        )
        patch_dims = patches.shape[-1]
        return tf.reshape(patches, [batch_size, -1, patch_dims])

class PatchEncoder(keras.layers.Layer):
    def __init__(self, num_patches, projection_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_patches = num_patches
        self.projection = keras.layers.Dense(units=projection_dim)
        self.position_embedding = keras.layers.Embedding(input_dim=num_patches, output_dim=projection_dim)

    def call(self, patch):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        return self.projection(patch) + self.position_embedding(positions)

# ----------------------------------------------------------
# Data Loader for new dataset (real / spoof)
# ----------------------------------------------------------
class NewDataLoader:
    def __init__(self, base_dir, img_size=IMG_SIZE, batch_size=BATCH_SIZE, seed=SEED):
        self.base_dir = base_dir
        self.img_size = img_size
        self.batch_size = batch_size
        self.seed = seed

    def get_paths_labels(self):
        real_dir = os.path.join(self.base_dir, "real")
        spoof_dir = os.path.join(self.base_dir, "spoof")

        real_imgs = [os.path.join(real_dir, f) for f in os.listdir(real_dir) if f.lower().endswith(('.jpg','.jpeg','.png'))]
        spoof_imgs = [os.path.join(spoof_dir, f) for f in os.listdir(spoof_dir) if f.lower().endswith(('.jpg','.jpeg','.png'))]

        paths = real_imgs + spoof_imgs
        labels = [0]*len(real_imgs) + [1]*len(spoof_imgs)

        return shuffle(paths, labels, random_state=self.seed)

    def make_generator(self, image_paths, labels, augment=False):
        datagen = ImageDataGenerator(
            rescale=1./255,
            rotation_range=12 if augment else 0,
            width_shift_range=0.08 if augment else 0,
            height_shift_range=0.08 if augment else 0,
            horizontal_flip=augment,
            validation_split=0.2
        )

        df = pd.DataFrame({"filename": image_paths, "class": labels})
        train_gen = datagen.flow_from_dataframe(df, x_col="filename", y_col="class",
                                                target_size=self.img_size, batch_size=self.batch_size,
                                                class_mode="raw", subset="training", seed=self.seed)
        val_gen = datagen.flow_from_dataframe(df, x_col="filename", y_col="class",
                                              target_size=self.img_size, batch_size=self.batch_size,
                                              class_mode="raw", subset="validation", seed=self.seed)
        return train_gen, val_gen

# ----------------------------------------------------------
# Load base model safely
# ----------------------------------------------------------
print("Loading base ViT model from:", BASE_MODEL_PATH)
custom_objects = {"Patches": Patches, "PatchEncoder": PatchEncoder}
base_model = load_model(BASE_MODEL_PATH, custom_objects=custom_objects)
print("✅ Base model loaded safely.")

# Clone the model
model = keras.models.clone_model(base_model)
model.set_weights(base_model.get_weights())
model.compile(optimizer=keras.optimizers.Adam(1e-4),
              loss='binary_crossentropy',
              metrics=['accuracy', keras.metrics.AUC(name='auc')])
print("✅ Model cloned successfully — ready for new training.")

# ----------------------------------------------------------
# Load new dataset
# ----------------------------------------------------------
loader = NewDataLoader(NEW_DATASET_DIR)
paths, labels = loader.get_paths_labels()
train_gen, val_gen = loader.make_generator(paths, labels, augment=True)

# Compute class weights
cw = class_weight.compute_class_weight(class_weight='balanced',
                                       classes=np.unique(labels),
                                       y=np.array(labels))
class_weight_dict = dict(enumerate(cw))
print("Class weights:", class_weight_dict)

# ----------------------------------------------------------
# Callbacks
# ----------------------------------------------------------
best_cb = ModelCheckpoint(filepath=BEST_MODEL_KERAS, monitor='val_auc', mode='max',
                          save_best_only=True, verbose=1)
periodic_ckpt = ModelCheckpoint(
    filepath=os.path.join(CHECKPOINT_DIR, "ckpt_epoch_{epoch:02d}_newdatavit.weights.h5"),
    save_weights_only=True, verbose=0)
earlystop = EarlyStopping(monitor='val_loss', patience=10, verbose=1)
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, verbose=1)

callbacks = [best_cb, periodic_ckpt, earlystop, reduce_lr]

# ----------------------------------------------------------
# Train
# ----------------------------------------------------------
history = model.fit(train_gen, validation_data=val_gen,
                    epochs=EPOCHS, class_weight=class_weight_dict,
                    callbacks=callbacks, verbose=1)

# Save history to CSV
hist_df = pd.DataFrame(history.history)
hist_df.to_csv(HISTORY_CSV, index=False)
print("Saved training history CSV:", HISTORY_CSV)

# Save to JSON as well
with open(RESUME_JSON, "w") as f:
    json.dump(history.history, f)
print("Saved JSON metrics:", RESUME_JSON)

# ----------------------------------------------------------
# Evaluate on validation and metrics
# ----------------------------------------------------------
val_preds = model.predict(val_gen).ravel()
val_true = val_gen.labels[:len(val_preds)]
val_pred_bin = (val_preds > 0.5).astype(int)

cm = confusion_matrix(val_true, val_pred_bin)
print("Confusion Matrix:\n", cm)
print("Classification Report:\n", classification_report(val_true, val_pred_bin, digits=4))

auc_score = roc_auc_score(val_true, val_preds)
print("Validation AUC:", auc_score)

# ----------------------------------------------------------
# Save plots
# ----------------------------------------------------------
# Confusion matrix
plt.figure(figsize=(5, 4))
plt.imshow(cm, cmap=plt.cm.Blues)
plt.title("ViT (New Data) - Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("True")
plt.colorbar()
plt.tight_layout()
plt.savefig(os.path.join(NEW_RESULTS_DIR, "confusion_matrix_newdatavit.png"))
plt.close()

# ROC Curve
fpr, tpr, _ = roc_curve(val_true, val_preds)
plt.figure(figsize=(6, 6))
plt.plot(fpr, tpr, label=f"AUC={auc_score:.3f}")
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve (New Data)")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(NEW_RESULTS_DIR, "roc_curve_newdatavit.png"))
plt.close()

# Training Metrics Plot
plt.figure(figsize=(8, 5))
plt.plot(history.history['accuracy'], label='train_acc')
plt.plot(history.history['val_accuracy'], label='val_acc')
plt.plot(history.history['auc'], label='train_auc')
plt.plot(history.history['val_auc'], label='val_auc')
plt.title("ViT (New Data) - Training Progress")
plt.xlabel("Epochs")
plt.ylabel("Metrics")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(NEW_RESULTS_DIR, "training_metrics_newdatavit.png"))
plt.close()

# ----------------------------------------------------------
# Save models (Keras + H5 + TFLite)
# ----------------------------------------------------------
model.save(BEST_MODEL_KERAS)
model.save(BEST_MODEL_H5)
print("✅ Saved new ViT models:", BEST_MODEL_KERAS, BEST_MODEL_H5)

# TFLite export
try:
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    def rep_data():
        for i in range(30):
            imgs, _ = next(train_gen)
            yield [imgs.astype(np.float32)]
    converter.representative_dataset = rep_data
    tflite_model = converter.convert()
    with open(TFLITE_PATH, "wb") as f:
        f.write(tflite_model)
    print("✅ Saved quantized TFLite model:", TFLITE_PATH)
except Exception as e:
    print("⚠️ Quantized conversion failed, exporting float32 version:", e)
    tflite_model = tf.lite.TFLiteConverter.from_keras_model(model).convert()
    with open(TFLITE_PATH, "wb") as f:
        f.write(tflite_model)
    print("✅ Saved float32 TFLite model:", TFLITE_PATH)

print("🎯 Training complete. Results saved in:", NEW_RESULTS_DIR)
