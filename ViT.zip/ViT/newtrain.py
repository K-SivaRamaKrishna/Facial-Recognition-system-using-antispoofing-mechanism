# train_new_dataset_fullfinetune_v2.py
# ==========================================================
# FULL FINE-TUNE (resumable) on NEW dataset (real / spoof)
# - clones results/best_model.keras (kept safe)
# - full-layer fine-tuning (LR=1e-4)
# - saves new files under newdatasetmodel/
# - runs up to 50 epochs (no early stopping)
# ==========================================================

import os, time, glob, re, json, math, random
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array
from tensorflow.keras.callbacks import ModelCheckpoint, ReduceLROnPlateau
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, roc_auc_score
from sklearn.utils import shuffle, class_weight

# ---------------- CONFIG ----------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

OLD_MODEL_PATH = os.path.join("results", "best_model.keras")  # existing CASIA model (kept safe)
NEW_DATA_DIR = r"C:\Users\DELL\OneDrive\Pictures\data"        # contains "real" and "spoof"
NEW_RESULTS_DIR = "newdatasetmodel"                           # output folder (new files)

IMG_SIZE = (224, 224)
BATCH_SIZE = 16
EPOCHS = 50        # increased to 50
VAL_SIZE = 0.2
INITIAL_LR = 1e-4

os.makedirs(NEW_RESULTS_DIR, exist_ok=True)
CHECKPOINT_DIR = os.path.join(NEW_RESULTS_DIR, "checkpoints")
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# ---------------- filenames (new files) ----------------
def unique_path(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    ts = time.strftime("%Y%m%d-%H%M%S")
    return f"{base}_{ts}{ext}"

BEST_MODEL_KERAS = unique_path(os.path.join(NEW_RESULTS_DIR, "best_new_model.keras"))
BEST_MODEL_H5 = unique_path(os.path.join(NEW_RESULTS_DIR, "best_new_model.h5"))
HISTORY_CSV = os.path.join(NEW_RESULTS_DIR, "training_history_new.csv")
RESUME_INFO = os.path.join(NEW_RESULTS_DIR, "resume_info_new.json")
TFLITE_PATH = unique_path(os.path.join(NEW_RESULTS_DIR, "model_new.tflite"))
TRAIN_METRICS_PNG = os.path.join(NEW_RESULTS_DIR, "training_metrics_new.png")
ROC_PNG = os.path.join(NEW_RESULTS_DIR, "roc_curve_new.png")
CM_PNG = os.path.join(NEW_RESULTS_DIR, "confusion_matrix_new.png")

# ---------------- helpers ----------------
def latest_checkpoint(ckpt_dir, pattern=r"ckpt_epoch_(\d+)\.weights\.h5"):
    files = glob.glob(os.path.join(ckpt_dir, "ckpt_epoch_*.weights.h5"))
    if not files:
        return None, 0
    best_epoch, best_file = -1, None
    for f in files:
        m = re.search(pattern, os.path.basename(f))
        e = int(m.group(1)) if m else 0
        if e > best_epoch:
            best_epoch, best_file = e, f
    return best_file, best_epoch

def collect_image_paths_and_labels(base_dir):
    real_dir = os.path.join(base_dir, "real")
    spoof_dir = os.path.join(base_dir, "spoof")
    if not os.path.isdir(real_dir) or not os.path.isdir(spoof_dir):
        raise FileNotFoundError(f"Expected 'real' and 'spoof' subfolders in {base_dir}")
    real = sorted([os.path.join(real_dir, f) for f in os.listdir(real_dir)
                   if f.lower().endswith(('.jpg','.jpeg','.png'))])
    spoof = sorted([os.path.join(spoof_dir, f) for f in os.listdir(spoof_dir)
                    if f.lower().endswith(('.jpg','.jpeg','.png'))])
    paths = real + spoof
    labels = [0]*len(real) + [1]*len(spoof)
    return paths, labels

def representative_data_gen(sample_paths, num_samples=50):
    for i, p in enumerate(sample_paths[:num_samples]):
        try:
            img = load_img(p, target_size=IMG_SIZE)
            arr = img_to_array(img).astype(np.float32) / 255.0
            arr = np.expand_dims(arr, axis=0)
            yield [arr]
        except Exception:
            continue

# ---------------- main training flow ----------------
def train_on_new_dataset():
    print("=== START: FULL FINE-TUNE (no early stop) ===")

    # load base model
    if not os.path.exists(OLD_MODEL_PATH):
        raise FileNotFoundError(f"Base model not found: {OLD_MODEL_PATH}")
    orig_model = keras.models.load_model(OLD_MODEL_PATH)
    model = keras.models.clone_model(orig_model)
    model.set_weights(orig_model.get_weights())

    for layer in model.layers:
        layer.trainable = True

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=INITIAL_LR),
        loss='binary_crossentropy',
        metrics=['accuracy', keras.metrics.AUC(name='auc')]
    )

    # dataset
    image_paths, labels = collect_image_paths_and_labels(NEW_DATA_DIR)
    image_paths, labels = shuffle(image_paths, labels, random_state=SEED)
    train_p, val_p, train_l, val_l = train_test_split(
        image_paths, labels, test_size=VAL_SIZE, stratify=labels, random_state=SEED
    )
    print(f"Train: {len(train_p)}, Val: {len(val_p)}")

    # data generators
    train_datagen = ImageDataGenerator(
        rescale=1./255, rotation_range=12,
        width_shift_range=0.08, height_shift_range=0.08,
        horizontal_flip=True
    )
    val_datagen = ImageDataGenerator(rescale=1./255)

    train_df = pd.DataFrame({"filename": train_p, "class": train_l})
    val_df = pd.DataFrame({"filename": val_p, "class": val_l})

    train_gen = train_datagen.flow_from_dataframe(
        train_df, x_col="filename", y_col="class",
        target_size=IMG_SIZE, batch_size=BATCH_SIZE,
        class_mode='raw', shuffle=True, seed=SEED
    )
    val_gen = val_datagen.flow_from_dataframe(
        val_df, x_col="filename", y_col="class",
        target_size=IMG_SIZE, batch_size=BATCH_SIZE,
        class_mode='raw', shuffle=False, seed=SEED
    )

    # callbacks
    best_cb = ModelCheckpoint(filepath=BEST_MODEL_KERAS, monitor='val_auc', mode='max',
                              save_best_only=True, verbose=1)
    ckpt_cb = ModelCheckpoint(
        filepath=os.path.join(CHECKPOINT_DIR, "ckpt_epoch_{epoch:02d}.weights.h5"),
        save_weights_only=True, save_freq='epoch', verbose=0
    )
    reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, verbose=1)

    # class weights
    cw = class_weight.compute_class_weight(class_weight='balanced',
                                           classes=np.unique(labels),
                                           y=np.array(labels))
    cw_dict = dict(enumerate(cw))

    # train
    history = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=EPOCHS,
        class_weight=cw_dict,
        callbacks=[best_cb, ckpt_cb, reduce_lr],
        verbose=1
    )

    pd.DataFrame(history.history).to_csv(HISTORY_CSV, index=False)
    print("Saved history ->", HISTORY_CSV)

    # plot metrics
    plt.figure(figsize=(10, 5))
    plt.plot(history.history['accuracy'], label='train_acc')
    plt.plot(history.history['val_accuracy'], label='val_acc')
    plt.plot(history.history['auc'], label='train_auc')
    plt.plot(history.history['val_auc'], label='val_auc')
    plt.legend(); plt.grid(True)
    plt.tight_layout(); plt.savefig(TRAIN_METRICS_PNG)
    plt.close()
    print("Saved metrics plot ->", TRAIN_METRICS_PNG)

    # load best model
    best_model = keras.models.load_model(BEST_MODEL_KERAS)
    best_model.save(BEST_MODEL_H5)
    print("Saved H5 copy ->", BEST_MODEL_H5)

    # evaluate
    val_gen.reset()
    y_scores = best_model.predict(val_gen)
    y_scores = y_scores.ravel()
    y_pred = (y_scores > 0.5).astype(int)
    y_true = np.array(val_l)

    cm = confusion_matrix(y_true, y_pred)
    print("Confusion Matrix:\n", cm)
    print(classification_report(y_true, y_pred, digits=4))

    plt.imshow(cm, cmap='Blues'); plt.title('Confusion Matrix')
    plt.xlabel('Predicted'); plt.ylabel('True')
    plt.tight_layout(); plt.savefig(CM_PNG)
    plt.close()
    print("Saved confusion matrix ->", CM_PNG)

    auc_val = roc_auc_score(y_true, y_scores)
    fpr, tpr, _ = roc_curve(y_true, y_scores)
    plt.plot(fpr, tpr, label=f"AUC={auc_val:.3f}")
    plt.plot([0,1],[0,1],'k--')
    plt.legend(); plt.title('ROC Curve')
    plt.tight_layout(); plt.savefig(ROC_PNG)
    plt.close()
    print("Saved ROC ->", ROC_PNG)

    # TFLite
    print("Converting to TFLite...")
    converter = tf.lite.TFLiteConverter.from_keras_model(best_model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = lambda: representative_data_gen(train_p, 50)
    try:
        tflite_model = converter.convert()
        with open(TFLITE_PATH, 'wb') as f: f.write(tflite_model)
        print("Saved quantized TFLite ->", TFLITE_PATH)
    except Exception as e:
        print("Quantized TFLite failed:", e)
        tflite_model = tf.lite.TFLiteConverter.from_keras_model(best_model).convert()
        with open(TFLITE_PATH, 'wb') as f: f.write(tflite_model)
        print("Saved fallback float32 TFLite ->", TFLITE_PATH)

    json.dump({
        "epochs_completed": len(history.history['loss']),
        "best_model": BEST_MODEL_KERAS,
        "final_auc": float(auc_val),
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }, open(RESUME_INFO, "w"), indent=2)
    print("Saved JSON ->", RESUME_INFO)

    print("\n✅ TRAINING COMPLETE (50 epochs) — results saved in:", os.path.abspath(NEW_RESULTS_DIR))


if __name__ == "__main__":
    train_on_new_dataset()
