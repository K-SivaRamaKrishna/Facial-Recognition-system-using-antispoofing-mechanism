# ==========================================================
# FACE ANTI-SPOOFING — RESUMABLE TRAINING (Vision Transformer)
# Fixes: class_mode error (binary vs raw), unique model names, resume checkpoints
# Compatible: TF >=2.16 / Keras 3
# ==========================================================
import os
import re
import json
import time
import glob
import math
import random
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, roc_auc_score
from sklearn.utils import shuffle, class_weight
import matplotlib.pyplot as plt

# ---------------------------
# CONFIG
# ---------------------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

# ---------- EDIT THIS ----------
DATA_DIR = r"C:\Users\DELL\Downloads\preprocessed_casia_final\images"  # expected layout: train/live, train/spoof, test/live, test/spoof
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 15
VAL_SIZE = 0.2
RESULTS_DIR = "results_ViT"
# -------------------------------

os.makedirs(RESULTS_DIR, exist_ok=True)
CHECKPOINT_DIR = os.path.join(RESULTS_DIR, "checkpoints")
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# default file names (they will be uniquified if already exist)
BEST_MODEL_KERAS = os.path.join(RESULTS_DIR, "ViTmodel.keras")
BEST_MODEL_H5 = os.path.join(RESULTS_DIR, "ViTmodel.h5")
HISTORY_CSV = os.path.join(RESULTS_DIR, "training_history.csv")
RESUME_INFO = os.path.join(RESULTS_DIR, "resume_info.json")
TFLITE_PATH = os.path.join(RESULTS_DIR, "ViTmodel.tflite")

# ---------------------------
# Utilities
# ---------------------------
def unique_path(path):
    """If path exists, append timestamp (before ext or as suffix for dir)."""
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    ts = time.strftime("%Y%m%d-%H%M%S")
    new_path = f"{base}_{ts}{ext}"
    return new_path

def latest_checkpoint(ckpt_dir, pattern=r"ckpt_epoch_(\d+)\.weights\.h5"):
    files = glob.glob(os.path.join(ckpt_dir, "ckpt_epoch_*.weights.h5"))
    if not files:
        return None, 0
    # extract epoch numbers and choose highest
    best_epoch = -1
    best_file = None
    for f in files:
        m = re.search(pattern, os.path.basename(f))
        if m:
            try:
                e = int(m.group(1))
            except:
                e = 0
        else:
            e = 0
        if e > best_epoch:
            best_epoch = e
            best_file = f
    return best_file, best_epoch

# ---------------------------
# Vision Transformer Components
# ---------------------------
def mlp(x, hidden_units, dropout_rate):
    for units in hidden_units:
        x = layers.Dense(units, activation=tf.nn.gelu)(x)
        x = layers.Dropout(dropout_rate)(x)
    return x

class Patches(layers.Layer):
    def __init__(self, patch_size, **kwargs):
        super(Patches, self).__init__(**kwargs)
        self.patch_size = patch_size

    def call(self, images):
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1, 1, 1, 1],
            padding="VALID",
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches

    def get_config(self):
        config = super(Patches, self).get_config()
        config.update({"patch_size": self.patch_size})
        return config

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim, **kwargs):
        super(PatchEncoder, self).__init__(**kwargs)
        self.num_patches = num_patches
        self.projection_dim = projection_dim
        self.projection = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(
            input_dim=num_patches, output_dim=projection_dim
        )

    def call(self, patch):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded = self.projection(patch) + self.position_embedding(positions)
        return encoded

    def get_config(self):
        config = super(PatchEncoder, self).get_config()
        config.update({
            "num_patches": self.num_patches,
            "projection_dim": self.projection_dim
        })
        return config

# ---------------------------
# ViT Model Builder
# ---------------------------
def build_ViT_model(
    img_size=IMG_SIZE,
    patch_size=16,
    num_heads=8,
    projection_dim=64,
    transformer_layers=8,
    mlp_head_units=[128]
):
    """Build Vision Transformer model for binary classification"""
    num_patches = (img_size[0] // patch_size) ** 2
    inputs = layers.Input(shape=img_size + (3,))
    
    # Create patches
    patches = Patches(patch_size)(inputs)
    
    # Encode patches
    encoded_patches = PatchEncoder(num_patches, projection_dim)(patches)

    # Create multiple transformer blocks
    for _ in range(transformer_layers):
        # Layer normalization 1
        x1 = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
        
        # Multi-head attention
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=projection_dim, dropout=0.1
        )(x1, x1)
        
        # Skip connection 1
        x2 = layers.Add()([attention_output, encoded_patches])
        
        # Layer normalization 2
        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        
        # MLP
        x3 = mlp(x3, hidden_units=[projection_dim * 2, projection_dim], dropout_rate=0.1)
        
        # Skip connection 2
        encoded_patches = layers.Add()([x3, x2])

    # Final layer normalization and global average pooling
    representation = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
    representation = layers.GlobalAveragePooling1D()(representation)
    representation = layers.Dropout(0.5)(representation)
    
    # MLP head for classification
    features = mlp(representation, hidden_units=mlp_head_units, dropout_rate=0.5)
    
    # Output layer
    outputs = layers.Dense(1, activation='sigmoid')(features)
    
    # Create model
    model = keras.Model(inputs=inputs, outputs=outputs)
    
    # Compile model
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-4),
        loss='binary_crossentropy',
        metrics=['accuracy', keras.metrics.AUC(name='auc')]
    )
    
    return model

# ---------------------------
# Data loader (flow_from_dataframe with class_mode='raw')
# ---------------------------
class FaceAntiSpoofingDataLoader:
    def __init__(self, base_dir, img_size=IMG_SIZE, batch_size=BATCH_SIZE, seed=SEED):
        self.base_dir = base_dir
        self.img_size = img_size
        self.batch_size = batch_size
        self.seed = seed

    def _collect(self, subset):  # subset: "train" or "test"
        live_dir = os.path.join(self.base_dir, subset, "live")
        spoof_dir = os.path.join(self.base_dir, subset, "spoof")
        live = sorted([os.path.join(live_dir, f) for f in os.listdir(live_dir) if f.lower().endswith(('.jpg','.jpeg','.png'))])
        spoof = sorted([os.path.join(spoof_dir, f) for f in os.listdir(spoof_dir) if f.lower().endswith(('.jpg','.jpeg','.png'))])
        paths = live + spoof
        labels = [0]*len(live) + [1]*len(spoof)
        return paths, labels

    def get_image_paths_and_labels(self):
        train_paths, train_labels = self._collect("train")
        test_paths, test_labels = self._collect("test")
        # deterministic shuffle
        train_paths, train_labels = shuffle(train_paths, train_labels, random_state=self.seed)
        test_paths, test_labels = shuffle(test_paths, test_labels, random_state=self.seed)
        return (train_paths, train_labels), (test_paths, test_labels)

    def make_generator(self, image_paths, labels, augmentation=False, shuffle_data=True):
        datagen = ImageDataGenerator(
            rescale=1./255,
            rotation_range=12 if augmentation else 0,
            width_shift_range=0.08 if augmentation else 0,
            height_shift_range=0.08 if augmentation else 0,
            horizontal_flip=augmentation
        )
        df = pd.DataFrame({"filename": image_paths, "class": labels})
        # IMPORTANT: use class_mode='raw' so numeric labels are returned as-is
        gen = datagen.flow_from_dataframe(
            dataframe=df,
            x_col="filename",
            y_col="class",
            target_size=self.img_size,
            batch_size=self.batch_size,
            class_mode='raw',   # <-- fixed (raw numeric labels)
            shuffle=shuffle_data,
            seed=self.seed
        )
        return gen, len(image_paths)

# ---------------------------
# Main training/resume flow
# ---------------------------
def main():
    # make sure filenames won't overwrite existing models (unique them if exists)
    global BEST_MODEL_KERAS, BEST_MODEL_H5
    BEST_MODEL_KERAS = unique_path(BEST_MODEL_KERAS)
    BEST_MODEL_H5 = unique_path(BEST_MODEL_H5)

    loader = FaceAntiSpoofingDataLoader(DATA_DIR)
    (train_paths, train_labels), (test_paths, test_labels) = loader.get_image_paths_and_labels()

    # Split train -> train/val
    train_p, val_p, train_l, val_l = train_test_split(
        train_paths, train_labels,
        test_size=VAL_SIZE,
        random_state=SEED,
        stratify=train_labels
    )

    # Create generators (note: we keep label lists train_l,val_l,test_labels separately)
    train_gen, train_samples = loader.make_generator(train_p, train_l, augmentation=True, shuffle_data=True)
    val_gen, val_samples = loader.make_generator(val_p, val_l, augmentation=False, shuffle_data=False)
    test_gen, test_samples = loader.make_generator(test_paths, test_labels, augmentation=False, shuffle_data=False)

    print(f"Dataset: train={train_samples}, val={val_samples}, test={test_samples}")

    # Build ViT model
    model = build_ViT_model()
    model.summary()

    # Callbacks
    # Best model saved in Keras native format (ModelCheckpoint will create this file)
    best_cb = ModelCheckpoint(filepath=BEST_MODEL_KERAS, monitor='val_auc', mode='max', save_best_only=True, verbose=1, save_weights_only=False)
    # Periodic weights-only checkpoints for resume (one file per epoch)
    periodic_ckpt_path = os.path.join(CHECKPOINT_DIR, "ckpt_epoch_{epoch:02d}.weights.h5")
    periodic_cb = ModelCheckpoint(filepath=periodic_ckpt_path, save_weights_only=True, save_freq='epoch', verbose=0)
    earlystop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=False, verbose=1)
    reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, verbose=1)

    callbacks = [best_cb, periodic_cb, earlystop, reduce_lr]

    # Class weights computed from training label list (avoid generator.classes reliance)
    classes = np.unique(np.array(train_l))
    cw = class_weight.compute_class_weight(class_weight='balanced', classes=classes, y=np.array(train_l))
    class_weight_dict = dict(enumerate(cw))
    print("Class weights:", class_weight_dict)

    # Resume support: find latest checkpoint and history length
    ckpt_file, ckpt_epoch = latest_checkpoint(CHECKPOINT_DIR)
    initial_epoch = 0
    if os.path.exists(HISTORY_CSV):
        try:
            hist_df = pd.read_csv(HISTORY_CSV)
            initial_epoch = len(hist_df)
            print(f"Found history CSV with {initial_epoch} rows; will resume from epoch {initial_epoch}.")
        except Exception as e:
            print("Could not read history CSV:", e)
            hist_df = None
    else:
        hist_df = None

    if ckpt_file:
        # if checkpoint epoch is larger than CSV-based initial_epoch, trust checkpoint too
        initial_epoch = max(initial_epoch, ckpt_epoch)
        print(f"Found checkpoint: {ckpt_file} (epoch {ckpt_epoch}). Loading weights and will resume from epoch {initial_epoch}.")
        model.load_weights(ckpt_file)
    else:
        print("No checkpoint found. Training from scratch.")

    # Steps
    steps_per_epoch = max(1, math.ceil(train_samples / BATCH_SIZE))
    validation_steps = max(1, math.ceil(val_samples / BATCH_SIZE))
    test_steps = max(1, math.ceil(test_samples / BATCH_SIZE))

    # Train
    history = model.fit(
        train_gen,
        epochs=EPOCHS,
        initial_epoch=initial_epoch,
        validation_data=val_gen,
        steps_per_epoch=steps_per_epoch,
        validation_steps=validation_steps,
        callbacks=callbacks,
        class_weight=class_weight_dict,
        verbose=1
    )

    # Merge/append history CSV
    new_hist_df = pd.DataFrame(history.history)
    if hist_df is not None and len(hist_df) > 0:
        combined = pd.concat([hist_df, new_hist_df], ignore_index=True)
        combined.to_csv(HISTORY_CSV, index=False)
    else:
        new_hist_df.to_csv(HISTORY_CSV, index=False)
    print("Saved/updated history CSV:", HISTORY_CSV)

    # Load best model (if checkpointed by ModelCheckpoint)
    if os.path.exists(BEST_MODEL_KERAS):
        print("Loading best ViT model:", BEST_MODEL_KERAS)
        # Use custom_objects to ensure proper loading of custom layers
        custom_objects = {
            'Patches': Patches,
            'PatchEncoder': PatchEncoder
        }
        best_model = keras.models.load_model(BEST_MODEL_KERAS, custom_objects=custom_objects)
    else:
        print("Best ViT model not found — using current model weights.")
        best_model = model

    # Save an H5 copy (if desired)
    try:
        best_model.save(BEST_MODEL_H5)
        print("Saved ViT HDF5 copy at:", BEST_MODEL_H5)
    except Exception as e:
        print("Could not save H5 model (continuing):", e)

    # Evaluate on test set
    print("Evaluating on test set...")
    eval_res = best_model.evaluate(test_gen, steps=test_steps, verbose=1)
    print("Test eval:", eval_res)

    # Predictions (we use test_labels list to compute metrics; generator is not shuffled)
    y_scores = best_model.predict(test_gen, steps=test_steps)
    y_scores = np.array(y_scores).ravel()[:len(test_labels)]
    y_pred = (y_scores > 0.5).astype(int)
    y_true = np.array(test_labels)[:len(y_scores)]

    # Metrics & plots
    cm = confusion_matrix(y_true, y_pred)
    print("Confusion Matrix:\n", cm)
    print("Classification Report:\n", classification_report(y_true, y_pred, digits=4))
    try:
        auc_val = roc_auc_score(y_true, y_scores)
        print("Test AUC:", auc_val)
    except Exception as e:
        print("AUC compute failed:", e)
        auc_val = None

    # Save confusion matrix figure
    cm_path = os.path.join(RESULTS_DIR, "confusion_matrix.png")
    plt.figure(figsize=(5, 4))
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title("ViT - Confusion Matrix")
    plt.colorbar()
    plt.ylabel("True")
    plt.xlabel("Pred")
    plt.tight_layout()
    plt.savefig(cm_path)
    plt.close()
    print("Saved confusion matrix:", cm_path)

    # Save ROC
    if auc_val is not None:
        fpr, tpr, _ = roc_curve(y_true, y_scores)
        roc_path = os.path.join(RESULTS_DIR, "roc_curve.png")
        plt.figure(figsize=(6, 6))
        plt.plot(fpr, tpr, label=f"AUC={auc_val:.3f}")
        plt.plot([0, 1], [0, 1], 'k--')
        plt.xlabel("False Positive Rate")
        plt.ylabel("True Positive Rate")
        plt.title("ViT - ROC Curve")
        plt.legend(loc='lower right')
        plt.tight_layout()
        plt.savefig(roc_path)
        plt.close()
        print("Saved ROC curve:", roc_path)

    # Save consolidated training plot from CSV
    try:
        hist_df_all = pd.read_csv(HISTORY_CSV)
        plt.figure(figsize=(10, 5))
        if 'accuracy' in hist_df_all.columns:
            plt.plot(hist_df_all['accuracy'], label='train_acc')
        if 'val_accuracy' in hist_df_all.columns:
            plt.plot(hist_df_all['val_accuracy'], label='val_acc')
        if 'auc' in hist_df_all.columns:
            plt.plot(hist_df_all['auc'], label='train_auc')
        if 'val_auc' in hist_df_all.columns:
            plt.plot(hist_df_all['val_auc'], label='val_auc')
        plt.xlabel("Epoch")
        plt.ylabel("Metric")
        plt.title("ViT - Training Metrics")
        plt.legend()
        plt.grid(True)
        hist_plot_path = os.path.join(RESULTS_DIR, "training_metrics.png")
        plt.savefig(hist_plot_path)
        plt.close()
        print("Saved training metrics plot:", hist_plot_path)
    except Exception as e:
        print("Could not save consolidated training plot:", e)

    # TFLite conversion (attempt quantized conversion with representative dataset)
    print("Converting ViT to TFLite (attempting quantization)...")
    try:
        converter = tf.lite.TFLiteConverter.from_keras_model(best_model)
        converter.optimizations = [tf.lite.Optimize.DEFAULT]

        def rep_gen():
            # use a few batches from training generator
            for i in range(30):
                imgs, _ = train_gen.next()
                yield [imgs.astype(np.float32)]

        converter.representative_dataset = rep_gen
        tflite_model = converter.convert()
        with open(TFLITE_PATH, "wb") as f:
            f.write(tflite_model)
        print("Saved ViT TFLite model:", TFLITE_PATH)
    except Exception as e:
        print("ViT TFLite conversion failed (falling back to float32 export):", e)
        try:
            # fallback: non-quantized (float32) TFLite
            converter = tf.lite.TFLiteConverter.from_keras_model(best_model)
            tflite_model = converter.convert()
            with open(TFLITE_PATH, "wb") as f:
                f.write(tflite_model)
            print("Saved float32 ViT TFLite model:", TFLITE_PATH)
        except Exception as e2:
            print("Final ViT TFLite conversion attempt failed:", e2)

    # Save resume info
    completed_epochs = 0
    if os.path.exists(HISTORY_CSV):
        completed_epochs = len(pd.read_csv(HISTORY_CSV))
    resume_data = {"completed_epochs": completed_epochs, "last_checkpoint": ckpt_file or ""}
    with open(RESUME_INFO, "w") as f:
        json.dump(resume_data, f)
    print("Saved resume info:", RESUME_INFO)

    print("All done. ViT results folder:", RESULTS_DIR)

if __name__ == "__main__":
    main()