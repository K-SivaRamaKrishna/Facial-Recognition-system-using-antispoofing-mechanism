# ==========================================================
# FACE ANTI-SPOOFING LIVE DETECTION WITH ViT MODEL & MTCNN
# ==========================================================
import cv2
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import time
import os
from mtcnn import MTCNN

# ---------------------------
# ViT Model Components (must match training)
# ---------------------------
def mlp(x, hidden_units, dropout_rate):
    for units in hidden_units:
        x = layers.Dense(units, activation=tf.nn.gelu)(x)
        x = layers.Dropout(dropout_rate)(x)
    return x

class Patches(layers.Layer):
    def __init__(self, patch_size, **kwargs):
        super(Patches, self).__init__(**kwargs)
        self.patch_size = patch_size

    def call(self, images):
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1, 1, 1, 1],
            padding="VALID",
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches

    def get_config(self):
        config = super(Patches, self).get_config()
        config.update({"patch_size": self.patch_size})
        return config

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim, **kwargs):
        super(PatchEncoder, self).__init__(**kwargs)
        self.num_patches = num_patches
        self.projection_dim = projection_dim
        self.projection = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(
            input_dim=num_patches, output_dim=projection_dim
        )

    def call(self, patch):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded = self.projection(patch) + self.position_embedding(positions)
        return encoded

    def get_config(self):
        config = super(PatchEncoder, self).get_config()
        config.update({
            "num_patches": self.num_patches,
            "projection_dim": self.projection_dim
        })
        return config

# ---------------------------
# Face Detection Setup with MTCNN
# ---------------------------
class FaceAntiSpoofingLive:
    def __init__(self, model_path, img_size=(224, 224)):
        self.img_size = img_size
        
        # Initialize MTCNN face detector
        print("Initializing MTCNN face detector...")
        self.detector = MTCNN()
        
        # Load the trained ViT model
        print("Loading ViT model...")
        custom_objects = {
            'Patches': Patches,
            'PatchEncoder': PatchEncoder
        }
        self.model = keras.models.load_model(model_path, custom_objects=custom_objects)
        print("Model loaded successfully!")
        
        # Confidence threshold
        self.confidence_threshold = 0.5
        
    def preprocess_face(self, face_roi):
        """Preprocess face ROI for ViT model"""
        # Resize to model input size
        face_resized = cv2.resize(face_roi, self.img_size)
        
        # Convert BGR to RGB
        face_rgb = cv2.cvtColor(face_resized, cv2.COLOR_BGR2RGB)
        
        # Normalize pixel values
        face_normalized = face_rgb.astype(np.float32) / 255.0
        
        # Add batch dimension
        face_batch = np.expand_dims(face_normalized, axis=0)
        
        return face_batch
    
    def detect_faces(self, frame):
        """Detect faces in the frame using MTCNN"""
        # Convert BGR to RGB for MTCNN
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Detect faces
        results = self.detector.detect_faces(rgb_frame)
        
        faces = []
        for result in results:
            if result['confidence'] > 0.9:  # MTCNN confidence threshold
                x, y, width, height = result['box']
                
                # Ensure coordinates are positive
                x = max(0, x)
                y = max(0, y)
                
                # Get facial landmarks
                landmarks = result['keypoints']
                
                faces.append({
                    'box': (x, y, width, height),
                    'landmarks': landmarks,
                    'confidence': result['confidence']
                })
        
        return faces
    
    def predict_spoof(self, face_roi):
        """Predict if face is live or spoof"""
        processed_face = self.preprocess_face(face_roi)
        prediction = self.model.predict(processed_face, verbose=0)
        confidence = prediction[0][0]
        
        # Model outputs probability of spoof (1 = spoof, 0 = live)
        # So if confidence > 0.5, it's spoof; else live
        is_spoof = confidence > self.confidence_threshold
        spoof_confidence = confidence if is_spoof else 1 - confidence
        
        return is_spoof, spoof_confidence, confidence
    
    def draw_landmarks(self, frame, landmarks):
        """Draw facial landmarks on the frame"""
        # Define colors for different landmarks
        colors = {
            'left_eye': (0, 255, 255),    # Yellow
            'right_eye': (0, 255, 255),   # Yellow
            'nose': (255, 0, 0),          # Blue
            'mouth_left': (0, 0, 255),    # Red
            'mouth_right': (0, 0, 255)    # Red
        }
        
        # Draw each landmark
        for landmark_name, point in landmarks.items():
            color = colors.get(landmark_name, (255, 255, 255))
            cv2.circle(frame, point, 2, color, -1)
    
    def run_live_detection(self):
        """Run live face anti-spoofing detection"""
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open camera")
            return
        
        print("Starting live detection...")
        print("Press 'q' to quit, 'r' to reset statistics")
        
        # Statistics
        total_frames = 0
        live_detections = 0
        spoof_detections = 0
        fps = 0
        start_time = time.time()
        frame_count = 0
        
        # To optimize performance, we'll process every 2nd frame for face detection
        detection_interval = 2
        last_faces = []
        
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Error: Could not read frame")
                break
            
            # Flip frame horizontally for mirror effect
            frame = cv2.flip(frame, 1)
            
            current_time = time.time()
            fps = 1 / (current_time - start_time) if frame_count > 0 else 0
            start_time = current_time
            frame_count += 1
            
            # Detect faces (every 'detection_interval' frames for performance)
            if frame_count % detection_interval == 0:
                last_faces = self.detect_faces(frame)
            
            faces = last_faces
            
            # Process each detected face
            for face_data in faces:
                x, y, w, h = face_data['box']
                landmarks = face_data['landmarks']
                face_confidence = face_data['confidence']
                
                # Ensure the bounding box is within frame boundaries
                x1, y1 = max(0, x), max(0, y)
                x2, y2 = min(frame.shape[1], x + w), min(frame.shape[0], y + h)
                
                if x2 <= x1 or y2 <= y1:
                    continue
                
                # Extract face ROI
                face_roi = frame[y1:y2, x1:x2]
                
                if face_roi.size == 0:
                    continue
                
                # Predict spoof/live
                is_spoof, confidence, raw_score = self.predict_spoof(face_roi)
                
                # Update statistics
                if is_spoof:
                    spoof_detections += 1
                    color = (0, 0, 255)  # Red for spoof
                    label = f"SPOOF: {confidence:.2f}"
                else:
                    live_detections += 1
                    color = (0, 255, 0)  # Green for live
                    label = f"LIVE: {confidence:.2f}"
                
                total_frames += 1
                
                # Draw bounding box and label
                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                cv2.putText(frame, label, (x1, y1-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                
                # Draw face detection confidence
                cv2.putText(frame, f"Face: {face_confidence:.2f}", 
                           (x1, y1-35), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                
                # Draw facial landmarks
                self.draw_landmarks(frame, landmarks)
                
                # Draw confidence bar
                bar_width = 200
                bar_height = 20
                bar_x = x1
                bar_y = y2 + 10
                
                # Background bar
                cv2.rectangle(frame, (bar_x, bar_y), 
                            (bar_x + bar_width, bar_y + bar_height), (50, 50, 50), -1)
                
                # Confidence fill
                fill_width = int(bar_width * raw_score)
                cv2.rectangle(frame, (bar_x, bar_y), 
                            (bar_x + fill_width, bar_y + bar_height), color, -1)
                
                # Confidence text
                cv2.putText(frame, f"Raw: {raw_score:.3f}", 
                          (bar_x, bar_y + bar_height + 20), 
                          cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
            
            # Display statistics
            stats_y = 30
            cv2.putText(frame, f"FPS: {fps:.1f}", (10, stats_y), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(frame, f"Faces: {len(faces)}", (10, stats_y + 25), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(frame, f"Live: {live_detections}", (10, stats_y + 50), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.putText(frame, f"Spoof: {spoof_detections}", (10, stats_y + 75), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
            cv2.putText(frame, f"Total: {total_frames}", (10, stats_y + 100), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            # Display instructions
            cv2.putText(frame, "Press 'q' to quit, 'r' to reset", 
                       (10, frame.shape[0] - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            # Show frame
            cv2.imshow('Face Anti-Spoofing - ViT + MTCNN', frame)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('r'):
                # Reset statistics
                total_frames = 0
                live_detections = 0
                spoof_detections = 0
                print("Statistics reset")
        
        cap.release()
        cv2.destroyAllWindows()
        
        # Print final statistics
        print("\n=== Final Statistics ===")
        print(f"Total frames processed: {total_frames}")
        print(f"Live detections: {live_detections}")
        print(f"Spoof detections: {spoof_detections}")
        if total_frames > 0:
            print(f"Live percentage: {(live_detections/total_frames)*100:.1f}%")
            print(f"Spoof percentage: {(spoof_detections/total_frames)*100:.1f}%")

# ---------------------------
# Installation requirements check
# ---------------------------
def check_dependencies():
    """Check if required packages are installed"""
    try:
        import mtcnn
        print("✓ MTCNN is installed")
    except ImportError:
        print("✗ MTCNN is not installed. Install it with: pip install mtcnn")
        return False
    
    try:
        import tensorflow as tf
        print("✓ TensorFlow is installed")
    except ImportError:
        print("✗ TensorFlow is not installed. Install it with: pip install tensorflow")
        return False
    
    try:
        import cv2
        print("✓ OpenCV is installed")
    except ImportError:
        print("✗ OpenCV is not installed. Install it with: pip install opencv-python")
        return False
    
    return True

# ---------------------------
# Main execution
# ---------------------------
def main():
    # Check dependencies first
    if not check_dependencies():
        print("\nPlease install the missing dependencies and run the script again.")
        return
    
    # Path to your trained ViT model
    MODEL_PATH = "results_ViT/ViTmodel.keras"
    
    # If the above doesn't exist, try to find the latest model
    if not os.path.exists(MODEL_PATH):
        # Look for any .keras file in results_ViT directory
        results_dir = "results_ViT"
        if os.path.exists(results_dir):
            keras_files = [f for f in os.listdir(results_dir) if f.endswith('.keras')]
            if keras_files:
                # Use the first found .keras file (you might want to be more specific)
                MODEL_PATH = os.path.join(results_dir, keras_files[0])
                print(f"Using model: {MODEL_PATH}")
            else:
                print("Error: No .keras model file found in results_ViT directory")
                print("Please train the model first or specify the correct path")
                return
        else:
            print("Error: results_ViT directory not found")
            print("Please train the model first")
            return
    
    # Initialize and run live detection
    try:
        detector = FaceAntiSpoofingLive(MODEL_PATH)
        detector.run_live_detection()
    except Exception as e:
        print(f"Error during live detection: {e}")
        print("Make sure your model file is compatible and all dependencies are installed")

if __name__ == "__main__":
    main()